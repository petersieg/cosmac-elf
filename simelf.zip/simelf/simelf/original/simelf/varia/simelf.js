/*
   ELF COSMAC JavaScript simulator
   by Maciej Szyc 2005, cosmac'at'szyc.org
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
*/

var inData=0;
var dispData=0;

// Switch on/off
var s0_flag=false;
var s1_flag=false;
var s2_flag=false;
var s3_flag=false;
var s4_flag=false;
var s5_flag=false;
var s6_flag=false;
var s7_flag=false;

var load_flag=false;
var mp_flag=false;
var run_flag=false;
var in_flag=false;

switch_on = new Image(55, 30); switch_on.src="picts/on.gif";
switch_off = new Image(55, 30); switch_off.src="picts/off.gif";

function s0() {
  s0_flag= !s0_flag;
  document.s_0.src = (s0_flag ? switch_on.src : switch_off.src);
  if(s0_flag) inData |= 0x01;
  else inData &= 0xfe;
}

function s1() {
  s1_flag = !s1_flag;
  document.s_1.src = (s1_flag ? switch_on.src : switch_off.src);
  if(s1_flag) inData |= 0x02;
  else inData &= 0xfd;
}

function s2() {
  s2_flag = !s2_flag;
  document.s_2.src = (s2_flag ? switch_on.src : switch_off.src);
  if(s2_flag) inData |= 0x04;
  else inData &= 0xfb;
}

function s3() {
  s3_flag = !s3_flag;
  document.s_3.src = (s3_flag ? switch_on.src : switch_off.src);
  if(s3_flag) inData |= 0x08;
  else inData &= 0xf7;
}

function s4() {
  s4_flag = !s4_flag;
  document.s_4.src = (s4_flag ? switch_on.src : switch_off.src);
  if(s4_flag) inData |= 0x10;
  else inData &= 0xef;
}

function s5() {
  s5_flag = !s5_flag;
  document.s_5.src = (s5_flag ? switch_on.src : switch_off.src);
  if(s5_flag) inData |= 0x20;
  else inData &= 0xdf;
}

function s6() {
  s6_flag = !s6_flag;
  document.s_6.src = (s6_flag ? switch_on.src : switch_off.src);
  if(s6_flag) inData |= 0x40;
  else inData &= 0xbf;
}

function s7() {
  s7_flag = !s7_flag;
  document.s_7.src = (s7_flag ? switch_on.src : switch_off.src);
  if(s7_flag) inData |= 0x80;
  else inData &= 0x7f;
}

function load() {
  load_flag = !load_flag;
  document.s_load.src = (load_flag ? switch_on.src : switch_off.src);
}

function mp() {
  mp_flag = !mp_flag;
  document.s_mp.src = (mp_flag ? switch_on.src : switch_off.src);
}

function run() {
  run_flag = !run_flag;
  document.s_run.src = (run_flag ? switch_on.src : switch_off.src);
}


// Preload the display value
dsp_0 = new Image(35, 56); dsp_0.src="picts/dis_0.gif";
dsp_1 = new Image(35, 56); dsp_1.src="picts/dis_1.gif";
dsp_2 = new Image(35, 56); dsp_2.src="picts/dis_2.gif";
dsp_3 = new Image(35, 56); dsp_3.src="picts/dis_3.gif";
dsp_4 = new Image(35, 56); dsp_4.src="picts/dis_4.gif";
dsp_5 = new Image(35, 56); dsp_5.src="picts/dis_5.gif";
dsp_6 = new Image(35, 56); dsp_6.src="picts/dis_6.gif";
dsp_7 = new Image(35, 56); dsp_7.src="picts/dis_7.gif";
dsp_8 = new Image(35, 56); dsp_8.src="picts/dis_8.gif";
dsp_9 = new Image(35, 56); dsp_9.src="picts/dis_9.gif";
dsp_a = new Image(35, 56); dsp_a.src="picts/dis_a.gif";
dsp_b = new Image(35, 56); dsp_b.src="picts/dis_b.gif";
dsp_c = new Image(35, 56); dsp_c.src="picts/dis_c.gif";
dsp_d = new Image(35, 56); dsp_d.src="picts/dis_d.gif";
dsp_e = new Image(35, 56); dsp_e.src="picts/dis_e.gif";
dsp_f = new Image(35, 56); dsp_f.src="picts/dis_f.gif";

function display(dspData) {
  // Print the contents of 'dspData' onto the HEX display.

  temp = dspData & 0x0f;
  if(temp==0) document.dis_lo.src = dsp_0.src;
  if(temp==1) document.dis_lo.src = dsp_1.src;
  if(temp==2) document.dis_lo.src = dsp_2.src;
  if(temp==3) document.dis_lo.src = dsp_3.src;
  if(temp==4) document.dis_lo.src = dsp_4.src;
  if(temp==5) document.dis_lo.src = dsp_5.src;
  if(temp==6) document.dis_lo.src = dsp_6.src;
  if(temp==7) document.dis_lo.src = dsp_7.src;
  if(temp==8) document.dis_lo.src = dsp_8.src;
  if(temp==9) document.dis_lo.src = dsp_9.src;
  if(temp==10) document.dis_lo.src = dsp_a.src;
  if(temp==11) document.dis_lo.src = dsp_b.src;
  if(temp==12) document.dis_lo.src = dsp_c.src;
  if(temp==13) document.dis_lo.src = dsp_d.src;
  if(temp==14) document.dis_lo.src = dsp_e.src;
  if(temp==15) document.dis_lo.src = dsp_f.src;

  temp = (dspData>>4)&0x0f; 
  if(temp==0) document.dis_hi.src = dsp_0.src;
  if(temp==1) document.dis_hi.src = dsp_1.src;
  if(temp==2) document.dis_hi.src = dsp_2.src;
  if(temp==3) document.dis_hi.src = dsp_3.src;
  if(temp==4) document.dis_hi.src = dsp_4.src;
  if(temp==5) document.dis_hi.src = dsp_5.src;
  if(temp==6) document.dis_hi.src = dsp_6.src;
  if(temp==7) document.dis_hi.src = dsp_7.src;
  if(temp==8) document.dis_hi.src = dsp_8.src;
  if(temp==9) document.dis_hi.src = dsp_9.src;
  if(temp==10) document.dis_hi.src = dsp_a.src;
  if(temp==11) document.dis_hi.src = dsp_b.src;
  if(temp==12) document.dis_hi.src = dsp_c.src;
  if(temp==13) document.dis_hi.src = dsp_d.src;
  if(temp==14) document.dis_hi.src = dsp_e.src;
  if(temp==15) document.dis_hi.src = dsp_f.src;
}

led_on = new Image(10, 10); led_on.src="picts/led_on.gif";
led_off = new Image(10, 10); led_off.src="picts/led_off.gif";

function diode() {
  if(Q_flag) document.led.src = led_on.src;
  else document.led.src = led_off.src;
}

function inButton() {
  in_flag=true;
}

function about() {
  alert('COSMAC "ELF" simulator in JavaScript\nby Maciej Szyc cosmac(at)szyc.org\nDecember 2005, Swidnica, Poland.');
}


// main function

function startSimelf() {
//  speedTest();
  cpuReset();
  regsClear();
  ramClear();
  loadCount();
  mainLoop();
}

function speedTest() {
  cpuReset();
  regsClear();
  ramClear();
  mem[0]=0x77;
  mem[1]=0x30;
  mem[2]=0x00;
  today=new Date();
  speed=today.getTime();
  cpuLoop(125000);
  today=new Date();
  speed=today.getTime()-speed;
  speed=100000/speed;
  speed=Math.round(speed);
  speed/=100;
  alert("Simulator CPU speed: "+speed+" MHz")
}

function loadCount() {
  mem[0]=0xe1;
  mem[1]=0xf8;
  mem[2]=0x00;
  mem[3]=0xb1;
  mem[4]=0xf8;
  mem[5]=0x20;
  mem[6]=0xa1;
  mem[7]=0x64;
  mem[8]=0x21;
  mem[9]=0xf0;
  mem[10]=0xfc;
  mem[11]=0x01;
  mem[12]=0x51;
  mem[13]=0x31;
  mem[14]=0x12;
  mem[15]=0x7b;
  mem[16]=0x30;
  mem[17]=0x07;
  mem[18]=0x7a;
  mem[19]=0x30;
  mem[20]=0x07;
  mem[21]=0x00;
}

function loadRead() {
  mem[0]=0xe1;
  mem[1]=0xf8;
  mem[2]=0x00;
  mem[3]=0xb1;
  mem[4]=0xf8;
  mem[5]=0x10;
  mem[6]=0xa1;
  mem[7]=0x6c;
  mem[8]=0x64;
  mem[9]=0x30;
  mem[10]=0x00;
}

function loadGuess() {
  mem[0]=0x8a;
  mem[1]=0xab;
  mem[2]=0xf8;
  mem[3]=0xaa;
  mem[4]=0xa3;
  mem[5]=0x53;
  mem[6]=0xe3;
  mem[7]=0xf8;
  mem[8]=0x07;
  mem[9]=0xa4;
  mem[10]=0x64;
  mem[11]=0x23;
  mem[12]=0x2a;
  mem[13]=0x3f;
  mem[14]=0x0c;
  mem[15]=0x37;
  mem[16]=0x0f;
  mem[17]=0x6c;
  mem[18]=0x8b;
  mem[19]=0xf5;
  mem[20]=0x33;
  mem[21]=0x1a;
  mem[22]=0xf8;
  mem[23]=0x01;
  mem[24]=0x30;
  mem[25]=0x22;
  mem[26]=0x3a;
  mem[27]=0x20;
  mem[28]=0x53;
  mem[29]=0x64;
  mem[30]=0x30;
  mem[31]=0x1e;
  mem[32]=0xf8;
  mem[33]=0x10;
  mem[34]=0x53;
  mem[35]=0x64;
  mem[36]=0x23;
  mem[37]=0x24;
  mem[38]=0x84;
  mem[39]=0x3a;
  mem[40]=0x0c;
  mem[41]=0x8b;
  mem[42]=0x7b;
  mem[43]=0x30;
  mem[44]=0x1c
}

function mainLoop() {

  // Memory Protection
  if(mp_flag) memFlag=false;
  else memFlag=true;

  // CPU reset
  if(!run_flag && !load_flag) cpuReset();
  
  // Program loading
  if(load_flag && !run_flag && !mp_flag && in_flag) {
    memPcIn(inData);
    dispData=memPcOut();
    incPC();
  }

  // Program listing
  if(load_flag && !run_flag && mp_flag && in_flag) {
     dispData=memPcOut();
     incPC();
  }
  
  // Program runing
  if(run_flag && !load_flag) {
     cpuLoop(12500);
  }
  
  display(dispData);
  diode();
  dispFlag=false;
  in_flag=false;

  setTimeout("mainLoop()",0);
}