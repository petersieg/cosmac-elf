/*
   1802 COSMAC microprocessor JavaScript simulator
   by Maciej Szyc 2005, cosmac'at'szyc.org
   
   based on 6502 JavaScript emulator by N.Landsteiner
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
*/

// global

var memFlag=true;
var dataBus=0;


// registers & memory

/*
   D  | 8bits  | Data Register (Accumulator)
   DF | 1bit   | Data Flag (ALU Carry)
   B  | 8bits  | Auxiliary Holding Register
   R  | 16bits | 1 of 16 Scratchpad Registers
   P  | 4bits  | Designates which register is Program Counter
   X  | 4bits  | Designates which register is Data Pointer
   N  | 4bits  | Holds Low-Order Instruction Digit
   I  | 4bits  | Holds High-Order Instruction Digit
   T  | 8bits  | Holds old X, P after interrupt (X is high nibble)
   IE | 1bit   | Interrupt Enable
   Q  | 1bit   | Output Flip-Flop
*/

var D_reg, B_reg, P_reg, X_reg, N_reg, I_reg, T_reg;
var DF_flag, IE_flag, Q_flag;
var EF1_flag, EF2_flag, EF3_flag, EF4_flag;

var R_regs= new Array(16);

var mem= new Array(256);

// elf hardware
var dispFlag=false;
var inTemp;

//General Functions

function PC() { return R_regs[P_reg] || 0 }
function setPC(data) { R_regs[P_reg]=(data & 0xffff) }
function incPC() { R_regs[P_reg]++; R_regs[P_reg]&=0xffff }

function memPcIn(data) { addr=PC(); mem[addr]=data }
function memPcOut() { addr=PC(); return mem[addr] & 0xff }

function memXregIn(data) { addr=R_regs[X_reg]; mem[addr]=data }
function memXregOut() { addr=R_regs[X_reg]; return mem[addr] & 0xff }


// Register Operations

function inc(k) { R_regs[k]++; R_regs[k]&=0xffff }

function dec(k) {
  if(R_regs[k]==0) R_regs[k]=0xffff;
  else R_regs[k]--
}

function irx() { R_regs[X_reg]++; R_regs[X_reg]&=0xffff }

function glo(k) { D_reg=R_regs[k]&255 }

function ghi(k) { D_reg=(R_regs[k]&0xff00)>>8 }

function plo(k) { R_regs[k]&=0xff00; R_regs[k]|=D_reg }

function phi(k) { R_regs[k]=(D_reg*256)|(R_regs[k]&0xff) }


// Memory Reference

function ldn(k) { D_reg=mem[R_regs[k]] }

function lda(k) {
  D_reg=mem[R_regs[k]];
  R_regs[k]++; R_regs[k]&=0xffff
}

function ldx() { D_reg=memXregOut() }

function ldxa() {
  D_reg=memXregOut();
  R_regs[X_reg]++; R_regs[X_reg]&=0xffff
}

function ldi() { D_reg=memPcOut(); incPC() }

function str(k) { if(memFlag) mem[R_regs[k]]=D_reg }

function stxd() {
  if(memFlag) memXregIn(D_reg);
  if(R_regs[X_reg]==0) R_regs[X_reg]=0xffff;
  else R_regs[X_reg]--
}

// Logic Operations

function or() { D_reg|=memXregOut() }

function ori() { D_reg|=memXregOut(); incPC() }

function xor() { D_reg^=memXregOut() }

function xri() { D_reg^=memXregOut(); incPC() }

function and() { D_reg&=memXregOut() }

function ani() { D_reg&=memXregOut(); incPC() }

function shr() {
  if(D_reg & 1) DF_flag=true;
  else DF_flag=false;
  D_reg=D_reg>>1;
  D_reg&=0x7f
}

function rshr() {
  flag=DF_flag;
  if(D_reg & 1) DF_flag=true;
  else DF_flag=false;
  D_reg=D_reg>>1;
  D_reg&=0x7f;
  if(flag) D_reg|=0x80;
}

function shl() {
  if(D_reg & 0x80) DF_flag=true;
  else DF_flag=false;
  D_reg=D_reg<<1;
  D_reg&=0xfe
}

function rshl() {
  flag=DF_flag;
  if(D_reg & 0x80) DF_flag=true;
  else DF_flag=false;
  D_reg=D_reg<<1;
  D_reg&=0xfe;
  if(flag) D_reg|=1;
}

// Aritmetic Operations

function add() { 
  D_reg+=memXregOut();
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff
}

function adi() { 
  D_reg+=memPcOut();
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff; incPC()
}

function adc() { 
  D_reg+=memXregOut(); D_reg+=DF_flag;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff
}

function adci() { 
  D_reg+=memPcOut(); D_reg+=DF_flag;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff; incPC()
}

function sd() { 
  D_reg=memXregOut()+0xff-D_reg+1;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff
}

function sdi() { 
  D_reg=memPcOut()+0xff-D_reg+1;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff; incPC()
}

function sdb() { 
  D_reg=memXregOut()+0xff-D_reg;
  D_reg+=(0xff-memXregOut());
  if(DF_flag) D_reg++;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff
}

function sdbi() { 
  D_reg=memPcOut()+0xff-D_reg;
  if(DF_flag) D_reg++;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff; incPC()
}

function sm() { 
  D_reg=D_reg+0xff-memXregOut()+1;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff
}

function smi() { 
  D_reg=D_reg+0xff-memPcOut()+1;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff; incPC()
}

function smb() { 
  D_reg=D_reg+0xff-memXregOut();
  if(DF_flag) D_reg++;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff
}

function smbi() { 
  D_reg=D_reg+0xff-memPcOut();
  if(DF_flag) D_reg++;
  if(D_reg>0xff) DF_flag=true;
  else DF_flag=false;
  D_reg&=0xff; incPC()
}

// Branching

function br() { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }

function bz() {
  if(D_reg==0) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bnz() {
  if(D_reg!=0) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bdf() {
  if(DF_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bnf() {
  if(!DF_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bq() {
  if(Q_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bnq() {
  if(!Q_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function b1() {
  if(EF1_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bn1() {
  if(!EF1_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function b2() {
  if(EF2_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bn2() {
  if(!EF2_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function b3() {
  if(EF3_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bn3() {
  if(!EF3_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function b4() {
  if(EF4_flag) { addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function bn4() {
  if(!EF4_flag & inTemp) { inTemp--; addr=(PC() & 0xff00); addr|=memPcOut(); setPC(addr) }
  else incPC()
}

function lbr() { addr=256*memPcOut(); incPC(); addr|=memPcOut(); setPC(addr) }

function lbz() {
  if(D_reg==0) { addr=256*memPcOut(); incPC(); addr|=memPcOut(); setPC(addr) }
  else { incPC(); incPC() }
}

function lbnz() {
  if(D_reg!=0) { addr=256*memPcOut(); incPC(); addr|=memPcOut(); setPC(addr) }
  else { incPC(); incPC() }
}

function lbdf() {
  if(DF_flag) { addr=256*memPcOut(); incPC(); addr|=memPcOut(); setPC(addr) }
  else { incPC(); incPC() }
}

function lbnf() {
  if(!DF_flag) { addr=256*memPcOut(); incPC(); addr|=memPcOut(); setPC(addr) }
  else { incPC(); incPC() }
}

function lbq() {
  if(Q_flag) { addr=256*memPcOut(); incPC(); addr|=memPcOut(); setPC(addr) }
  else { incPC(); incPC() }
}

function lbnq() {
  if(!Q_flag) { addr=256*memPcOut(); incPC(); addr|=memPcOut(); setPC(addr) }
  else { incPC(); incPC() }
}

// Skip instructions

function lsz() { if(D_reg==0) { incPC(); incPC() } }

function lsnz() { if(D_reg!=0) { incPC(); incPC() } }

function lsdf() { if(DF_flag) { incPC(); incPC() } }

function lsnf() { if(!DF_flag) { incPC(); incPC() } }

function lsq() { if(Q_flag) { incPC(); incPC() } }

function lsnq() { if(!Q_flag) { incPC(); incPC() } }

function lsie() { if(IE_flag) { incPC(); incPC() } }


// Control instructions

function sep(k) { N_reg=k; P_reg=N_reg }

function sex(k) { N_reg=k; X_reg=N_reg }

// Input/Output Byte Tranfer

function out(k) {
  dataBus=memXregOut();
  if(k&4) { dispData=dataBus; dispFlag=true }  // elf hardware
  R_regs[X_reg]++; R_regs[X_reg]&=0xffff
}

function inp(k) {
  if(k&4) dataBus=inData;  // elf hardware
  memXregIn(dataBus); dataBus=D_reg;
}

//
function i00() { incPC() }

function i01() { incPC(); ldn(1) }
function i02() { incPC(); ldn(2) }
function i03() { incPC(); ldn(3) }
function i04() { incPC(); ldn(4) }
function i05() { incPC(); ldn(5) }
function i06() { incPC(); ldn(6) }
function i07() { incPC(); ldn(7) }
function i08() { incPC(); ldn(8) }
function i09() { incPC(); ldn(9) }
function i0a() { incPC(); ldn(10) }
function i0b() { incPC(); ldn(11) }
function i0c() { incPC(); ldn(12) }
function i0d() { incPC(); ldn(13) }
function i0e() { incPC(); ldn(14) }
function i0f() { incPC(); ldn(15) }

function i10() { incPC(); inc(0) }
function i11() { incPC(); inc(1) }
function i12() { incPC(); inc(2) }
function i13() { incPC(); inc(3) }
function i14() { incPC(); inc(4) }
function i15() { incPC(); inc(5) }
function i16() { incPC(); inc(6) }
function i17() { incPC(); inc(7) }
function i18() { incPC(); inc(8) }
function i19() { incPC(); inc(9) }
function i1a() { incPC(); inc(10) }
function i1b() { incPC(); inc(11) }
function i1c() { incPC(); inc(12) }
function i1d() { incPC(); inc(13) }
function i1e() { incPC(); inc(14) }
function i1f() { incPC(); inc(15) }

function i20() { incPC(); dec(0) }
function i21() { incPC(); dec(1) }
function i22() { incPC(); dec(2) }
function i23() { incPC(); dec(3) }
function i24() { incPC(); dec(4) }
function i25() { incPC(); dec(5) }
function i26() { incPC(); dec(6) }
function i27() { incPC(); dec(7) }
function i28() { incPC(); dec(8) }
function i29() { incPC(); dec(9) }
function i2a() { incPC(); dec(10) }
function i2b() { incPC(); dec(11) }
function i2c() { incPC(); dec(12) }
function i2d() { incPC(); dec(13) }
function i2e() { incPC(); dec(14) }
function i2f() { incPC(); dec(15) }

function i30() { incPC(); br() }
function i31() { incPC(); bq() }
function i32() { incPC(); bz() }
function i33() { incPC(); bdf() }
function i34() { incPC(); b1() }
function i35() { incPC(); b2() }
function i36() { incPC(); b3() }
function i37() { incPC(); b4() }
function i38() { incPC(); incPC() }
function i39() { incPC(); bnq() }
function i3a() { incPC(); bnz() }
function i3b() { incPC(); bnf() }
function i3c() { incPC(); bn1() }
function i3d() { incPC(); bn2() }
function i3e() { incPC(); bn3() }
function i3f() { incPC(); bn4() }

function i40() { incPC(); lda(0) }
function i41() { incPC(); lda(1) }
function i42() { incPC(); lda(2) }
function i43() { incPC(); lda(3) }
function i44() { incPC(); lda(4) }
function i45() { incPC(); lda(5) }
function i46() { incPC(); lda(6) }
function i47() { incPC(); lda(7) }
function i48() { incPC(); lda(8) }
function i49() { incPC(); lda(9) }
function i4a() { incPC(); lda(10) }
function i4b() { incPC(); lda(11) }
function i4c() { incPC(); lda(12) }
function i4d() { incPC(); lda(13) }
function i4e() { incPC(); lda(14) }
function i4f() { incPC(); lda(15) }

function i50() { incPC(); str(0) }
function i51() { incPC(); str(1) }
function i52() { incPC(); str(2) }
function i53() { incPC(); str(3) }
function i54() { incPC(); str(4) }
function i55() { incPC(); str(5) }
function i56() { incPC(); str(6) }
function i57() { incPC(); str(7) }
function i58() { incPC(); str(8) }
function i59() { incPC(); str(9) }
function i5a() { incPC(); str(10) }
function i5b() { incPC(); str(11) }
function i5c() { incPC(); str(12) }
function i5d() { incPC(); str(13) }
function i5e() { incPC(); str(14) }
function i5f() { incPC(); str(15) }

function i60() { incPC(); irx() }
function i61() { incPC(); out(1) }
function i62() { incPC(); out(2) }
function i63() { incPC(); out(3) }
function i64() { incPC(); out(4) }
function i65() { incPC(); out(5) }
function i66() { incPC(); out(6) }
function i67() { incPC(); out(7) }
function i68() { incPC() }
function i69() { incPC(); inp(9) }
function i6a() { incPC(); inp(10) }
function i6b() { incPC(); inp(11) }
function i6c() { incPC(); inp(12) }
function i6d() { incPC(); inp(13) }
function i6e() { incPC(); inp(14) }
function i6f() { incPC(); inp(15) }

function i70() { incPC() }
function i71() { incPC() }
function i72() { incPC(); ldxa() }
function i73() { incPC(); stxd() }
function i74() { incPC(); adc() }
function i75() { incPC(); sdb() }
function i76() { incPC(); rshr() }
function i77() { incPC(); smb() }
function i78() { incPC() }
function i79() { incPC() }
function i7a() { incPC(); Q_flag=false; dispFlag=true }
function i7b() { incPC(); Q_flag=true;  dispFlag=true }
function i7c() { incPC(); adci() }
function i7d() { incPC(); sdbi() }
function i7e() { incPC(); rshl() }
function i7f() { incPC(); smbi() }

function i80() { incPC(); glo(0) }
function i81() { incPC(); glo(1) }
function i82() { incPC(); glo(2) }
function i83() { incPC(); glo(3) }
function i84() { incPC(); glo(4) }
function i85() { incPC(); glo(5) }
function i86() { incPC(); glo(6) }
function i87() { incPC(); glo(7) }
function i88() { incPC(); glo(8) }
function i89() { incPC(); glo(9) }
function i8a() { incPC(); glo(10) }
function i8b() { incPC(); glo(11) }
function i8c() { incPC(); glo(12) }
function i8d() { incPC(); glo(13) }
function i8e() { incPC(); glo(14) }
function i8f() { incPC(); glo(15) }

function i90() { incPC(); ghi(0) }
function i91() { incPC(); ghi(1) }
function i92() { incPC(); ghi(2) }
function i93() { incPC(); ghi(3) }
function i94() { incPC(); ghi(4) }
function i95() { incPC(); ghi(5) }
function i96() { incPC(); ghi(6) }
function i97() { incPC(); ghi(7) }
function i98() { incPC(); ghi(8) }
function i99() { incPC(); ghi(9) }
function i9a() { incPC(); ghi(10) }
function i9b() { incPC(); ghi(11) }
function i9c() { incPC(); ghi(12) }
function i9d() { incPC(); ghi(13) }
function i9e() { incPC(); ghi(14) }
function i9f() { incPC(); ghi(15) }

function ia0() { incPC(); plo(0) }
function ia1() { incPC(); plo(1) }
function ia2() { incPC(); plo(2) }
function ia3() { incPC(); plo(3) }
function ia4() { incPC(); plo(4) }
function ia5() { incPC(); plo(5) }
function ia6() { incPC(); plo(6) }
function ia7() { incPC(); plo(7) }
function ia8() { incPC(); plo(8) }
function ia9() { incPC(); plo(9) }
function iaa() { incPC(); plo(10) }
function iab() { incPC(); plo(11) }
function iac() { incPC(); plo(12) }
function iad() { incPC(); plo(13) }
function iae() { incPC(); plo(14) }
function iaf() { incPC(); plo(15) }

function ib0() { incPC(); phi(0) }
function ib1() { incPC(); phi(1) }
function ib2() { incPC(); phi(2) }
function ib3() { incPC(); phi(3) }
function ib4() { incPC(); phi(4) }
function ib5() { incPC(); phi(5) }
function ib6() { incPC(); phi(6) }
function ib7() { incPC(); phi(7) }
function ib8() { incPC(); phi(8) }
function ib9() { incPC(); phi(9) }
function iba() { incPC(); phi(10) }
function ibb() { incPC(); phi(11) }
function ibc() { incPC(); phi(12) }
function ibd() { incPC(); phi(13) }
function ibe() { incPC(); phi(14) }
function ibf() { incPC(); phi(15) }

function ic0() { incPC(); lbr() }
function ic1() { incPC(); lbq() }
function ic2() { incPC(); lbz() }
function ic3() { incPC(); lbdf() }
function ic4() { incPC() } // NOP
function ic5() { incPC(); lsnq() }
function ic6() { incPC(); lsnz() }
function ic7() { incPC(); lsnf() }
function ic8() { incPC(); incPC(); incPC() }
function ic9() { incPC(); lbnq() }
function ica() { incPC(); lbnz() }
function icb() { incPC(); lbnf() }
function icc() { incPC(); lsie() }
function icd() { incPC(); lsq() }
function ice() { incPC(); lsz() }
function icf() { incPC(); lsdf() }

function id0() { incPC(); sep(0) }
function id1() { incPC(); sep(1) }
function id2() { incPC(); sep(2) }
function id3() { incPC(); sep(3) }
function id4() { incPC(); sep(4) }
function id5() { incPC(); sep(5) }
function id6() { incPC(); sep(6) }
function id7() { incPC(); sep(7) }
function id8() { incPC(); sep(8) }
function id9() { incPC(); sep(9) }
function ida() { incPC(); sep(10) }
function idb() { incPC(); sep(11) }
function idc() { incPC(); sep(12) }
function idd() { incPC(); sep(13) }
function ide() { incPC(); sep(14) }
function idf() { incPC(); sep(15) }

function ie0() { incPC(); sex(0) }
function ie1() { incPC(); sex(1) }
function ie2() { incPC(); sex(2) }
function ie3() { incPC(); sex(3) }
function ie4() { incPC(); sex(4) }
function ie5() { incPC(); sex(5) }
function ie6() { incPC(); sex(6) }
function ie7() { incPC(); sex(7) }
function ie8() { incPC(); sex(8) }
function ie9() { incPC(); sex(9) }
function iea() { incPC(); sex(10) }
function ieb() { incPC(); sex(11) }
function iec() { incPC(); sex(12) }
function ied() { incPC(); sex(13) }
function iee() { incPC(); sex(14) }
function ief() { incPC(); sex(15) }

function if0() { incPC(); ldx() }
function if1() { incPC(); or() }
function if2() { incPC(); and() }
function if3() { incPC(); xor() }
function if4() { incPC(); add() }
function if5() { incPC(); sd() }
function if6() { incPC(); shr() }
function if7() { incPC(); sm() }
function if8() { incPC(); ldi() }
function if9() { incPC(); ori() }
function ifa() { incPC(); ani() }
function ifb() { incPC(); xri() }
function ifc() { incPC(); adi() }
function ifd() { incPC(); sdi() }
function ife() { incPC(); shl() }
function iff() { incPC(); smi() }


// code pages

var codes = [
  i00, i01, i02, i03, i04, i05, i06, i07,
  i08, i09, i0a, i0b, i0c, i0d, i0e, i0f,
  i10, i11, i12, i13, i14, i15, i16, i17,
  i18, i19, i1a, i1b, i1c, i1d, i1e, i1f,
  i20, i21, i22, i23, i24, i25, i26, i27,
  i28, i29, i2a, i2b, i2c, i2d, i2e, i2f,
  i30, i31, i32, i33, i34, i35, i36, i37,
  i38, i39, i3a, i3b, i3c, i3d, i3e, i3f,
  i40, i41, i42, i43, i44, i45, i46, i47,
  i48, i49, i4a, i4b, i4c, i4d, i4e, i4f,
  i50, i51, i52, i53, i54, i55, i56, i57,
  i58, i59, i5a, i5b, i5c, i5d, i5e, i5f,
  i60, i61, i62, i63, i64, i65, i66, i67,
  i68, i69, i6a, i6b, i6c, i6d, i6e, i6f,
  i70, i71, i72, i73, i74, i75, i76, i77,
  i78, i79, i7a, i7b, i7c, i7d, i7e, i7f,
  i80, i81, i82, i83, i84, i85, i86, i87,
  i88, i89, i8a, i8b, i8c, i8d, i8e, i8f,
  i90, i91, i92, i93, i94, i95, i96, i97,
  i98, i99, i9a, i9b, i9c, i9d, i9e, i9f,
  ia0, ia1, ia2, ia3, ia4, ia5, ia6, ia7,
  ia8, ia9, iaa, iab, iac, iad, iae, iaf,
  ib0, ib1, ib2, ib3, ib4, ib5, ib6, ib7,
  ib8, ib9, iba, ibb, ibc, ibd, ibe, ibf,
  ic0, ic1, ic2, ic3, ic4, ic5, ic6, ic7,
  ic8, ic9, ica, icb, icc, icd, ice, icf,
  id0, id1, id2, id3, id4, id5, id6, id7,
  id8, id9, ida, idb, idc, idd, ide, idf,
  ie0, ie1, ie2, ie3, ie4, ie5, ie6, ie7,
  ie8, ie9, iea, ieb, iec, ied, iee, ief,
  if0, if1, if2, if3, if4, if5, if6, if7,
  if8, if9, ifa, ifb, ifc, ifd, ife, iff
];

var cycles = [
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 00
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 10
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 20
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 30
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 40
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 50
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 60
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 70
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 80
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // 90
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // A0
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // B0
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,  // C0
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // D0
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,  // E0
  2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2   // F0
];

//main

function cpuLoop(cycleLimit) {
  cpuCycles=0;
  inTemp=Math.random()*255;
  inTemp=Math.round(inTemp);
  if(in_flag) EF4_flag=false;
  else EF4_flag=true;
  while(cpuCycles<cycleLimit && !dispFlag) {
    code=memPcOut();
    codes[code]();
    cpuCycles+=cycles[code];
  }
}

function cpuReset() {
  dataBus=0;
  I_reg=N_reg=X_reg=P_reg=0;
  IE_flag=true;
  Q_flag=false;
  EF1_flag=EF2_flag=EF3_flag=EF4_flag=true;
  R_regs[0]=0;
}

function regsClear() {
  for(k=0; k<16; k++) R_regs[k]=0;
}

function ramClear() {
  for(k=0; k<256; k++) mem[k]=0;
}


// end of cosmac
