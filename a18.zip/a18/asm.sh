#!/bin/sh
./a18 $1.asm -l $1.lst -o $1.hex
